-- EXAM TRACKER 2027: run this in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 class_level text,
 board text,
 created_at timestamptz default now()
);
create table if not exists public.exams (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 category text,
 application_start date,
 application_end date,
 exam_date date,
 admit_card_date date,
 result_date date,
 official_url text,
 verified boolean not null default false,
 created_at timestamptz default now()
);
create table if not exists public.resources (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 resource_type text not null check (resource_type in ('Notes','PYQ','Sample Paper','Formula Sheet','Other')),
 class_level text,
 board text,
 exam text,
 subject text,
 file_url text,
 verified boolean not null default false,
 created_at timestamptz default now()
);
create table if not exists public.mock_tests (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 exam text not null,
 description text,
 duration_minutes integer not null default 60,
 total_questions integer not null default 0,
 published boolean not null default false,
 created_at timestamptz default now()
);
create table if not exists public.mock_questions (
 id uuid primary key default gen_random_uuid(),
 test_id uuid not null references public.mock_tests(id) on delete cascade,
 question text not null,
 options jsonb not null,
 correct_option integer not null,
 explanation text,
 marks numeric default 4,
 negative_marks numeric default 1
);
alter table public.profiles enable row level security;
alter table public.exams enable row level security;
alter table public.resources enable row level security;
alter table public.mock_tests enable row level security;
alter table public.mock_questions enable row level security;
create policy "Users can view own profile" on public.profiles for select to authenticated using (auth.uid()=id);
create policy "Users can create own profile" on public.profiles for insert to authenticated with check (auth.uid()=id);
create policy "Users can update own profile" on public.profiles for update to authenticated using (auth.uid()=id);
create policy "Public can view verified exams" on public.exams for select using (verified=true);
create policy "Public can view verified resources" on public.resources for select using (verified=true);
create policy "Public can view published tests" on public.mock_tests for select using (published=true);
create policy "Public can view questions for published tests" on public.mock_questions for select using (exists(select 1 from public.mock_tests t where t.id=test_id and t.published=true));
-- Admin write policies should be added using a server-verified admin role/claim.
-- Do NOT rely on a client-side email check for database security.
