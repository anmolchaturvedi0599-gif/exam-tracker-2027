# EXAM TRACKER 2027

A bilingual (Hindi + English), free education portal starter built with Next.js and Supabase.

## Included
- Responsive landing page
- Email OTP sign-in / sign-up
- Student dashboard
- Exam calendar (database-backed)
- Notes and PYQ resource library (database-backed)
- Published mock-test catalogue
- Study planner starter
- Admin page starter for exam entries
- Supabase schema with Row Level Security starter policies

## Requirements
- Node.js 20+
- Supabase project
- Vercel account (deployment)

## Run locally
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add your Supabase project URL and anon key.
5. In Supabase SQL Editor, run `supabase/schema.sql`.
6. In Supabase Authentication > Providers > Email, enable email OTP and configure the email template to display the one-time token (`{{ .Token }}`).
7. Run `npm run dev` and open http://localhost:3000.

## Admin setup warning
The current admin page includes a convenience UI check only. It is NOT a secure admin authorization system. Before public launch, implement server-side admin role claims and matching RLS policies; never expose a Supabase service-role key in browser code. The schema intentionally leaves write policies for admins unimplemented.

## Important content policy
No official 2027 dates, PYQs, notes or mock questions are fabricated in this starter. Add only verified exam dates with official URLs and use original, licensed or permitted study material. Confirm current syllabus and exam rules from official authorities.

## Deploy to Vercel
1. Push this project to a private/public GitHub repository.
2. Import the repository in Vercel.
3. Add `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel Environment Variables.
4. Add the admin email variable only after the secure admin authorization implementation is completed.
5. Deploy, then add the deployed site URL to Supabase Auth > URL Configuration > Site URL and Redirect URLs.
6. Connect a custom domain in Vercel if desired.

## Production checklist
- Add server-side role-based admin access and admin RLS policies.
- Build profile onboarding (name, class, board, target exam).
- Build complete mock-test runner, timer, autosave, scoring and result analytics.
- Add private file storage with signed URLs and moderation.
- Add persistent student timetable and progress tracking.
- Add verified exam data workflow and content update timestamps.
- Test OTP delivery, rate limits, abuse protection, mobile layouts and accessibility.
